# 06_module
# folder: ecommerce
# --------------------------------------- sales2.py  ---------------------------------------
# convention: all lower cases and _
#
print(__name__, " module is initialized")
#


def calc_tax():
    print("calc_tax 2")


def calc_shipping():
    print("calc_shipping 2")
