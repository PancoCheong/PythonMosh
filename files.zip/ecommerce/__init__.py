print(__name__, " package is loaded")
