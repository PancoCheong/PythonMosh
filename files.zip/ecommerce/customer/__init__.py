# folder: in each package folder
# --------------------------------------- __init__.py  ---------------------------------------
#
# this file can be empty
#
# For relative imports to work in Python 3.6
# import os
# import sys
# sys.path.append(os.path.dirname(os.path.realpath(__file__)))

print(__name__, " package is loaded")
