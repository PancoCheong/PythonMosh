# 06_module
# folder: ecommerce\customer
# --------------------------------------- contact.py  ---------------------------------------
#
# convention: all lower cases and _
#


def contact_customer():
    print("contact_customer")


# contact_customer()          # output:contact_customer
print(__name__, " module is initialized")
