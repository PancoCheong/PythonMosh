def displaymessage():
    print("this message is from mymodule of pancopackage")
